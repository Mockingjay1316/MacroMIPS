void stream_copy(int *a, int *c, int N)
{
    int j;
    for (j=0; j<N; j++)
        c[j] = a[j];

}
